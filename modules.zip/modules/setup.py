config = {
    "version": "0.0.1",
    "admin": ""  # person tha twill receive build updates
}
